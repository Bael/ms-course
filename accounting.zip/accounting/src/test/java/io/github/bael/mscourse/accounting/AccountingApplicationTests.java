package io.github.bael.mscourse.accounting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountingApplicationTests {

	@Test
	void contextLoads() {
	}

}
